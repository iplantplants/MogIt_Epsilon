local i=MogIt.base.AddSlot("Crossbow",...)
--penis















