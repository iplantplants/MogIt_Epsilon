local i=MogIt.base.AddSlot("Wrist",...)
i(105748,nil,124862,4,nil,nil,64,3,nil,1,nil,nil,nil)