local i=MogIt.base.AddSlot("Waist",...)
i(105741,nil,124869,4,nil,nil,64,3,nil,1,nil,nil,nil)
i(117410,nil,137992,3,90,1,nil,4,nil,4,nil,991,nil)
i(118369,nil,137554,3,90,2,nil,4,nil,4,nil,990,nil)