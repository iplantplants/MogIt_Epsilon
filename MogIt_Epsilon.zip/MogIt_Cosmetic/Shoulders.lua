local i=MogIt.base.AddSlot("Shoulder",...)
i(105747,nil,124868,4,nil,nil,64,3,nil,1,nil,nil,nil)
i(117407,nil,137974,3,90,1,nil,4,nil,4,nil,991,nil)
i(118366,nil,137553,3,90,2,nil,4,nil,4,nil,990,nil)