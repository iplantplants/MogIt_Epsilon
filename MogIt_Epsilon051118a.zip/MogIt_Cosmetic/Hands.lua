local i=MogIt.base.AddSlot("Hands",...)
i(105744,nil,126142,4,nil,nil,64,3,nil,1,nil,nil,nil)
i(117409,nil,137995,3,90,1,nil,4,nil,4,nil,991,nil)
i(118368,nil,137281,3,90,2,nil,4,nil,4,nil,990,nil)